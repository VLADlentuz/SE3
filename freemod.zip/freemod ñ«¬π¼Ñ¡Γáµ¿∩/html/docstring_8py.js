var docstring_8py =
[
    [ "docstring.PyClass", "classdocstring_1_1_py_class.html", "classdocstring_1_1_py_class" ],
    [ "func", "docstring_8py.html#aec1a168f6e16b33f87fe6a37b9208957", null ]
];