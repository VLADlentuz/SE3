var dir_7278a1f1332cae93f55af2431cc49d08 =
[
    [ "mbascii.c", "mbascii_8c.html", null ],
    [ "mbascii.h", "mbascii_8h.html", null ]
];