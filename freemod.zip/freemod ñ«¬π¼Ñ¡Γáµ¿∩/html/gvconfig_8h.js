var gvconfig_8h =
[
    [ "gvconfig_plugin_install_from_library", "gvconfig_8h.html#ae2fa59f8f69eb2c85f84eaca09822609", null ]
];