var gvplugin__loadimage_8h =
[
    [ "gvloadimage_engine_s", "structgvloadimage__engine__s.html", "structgvloadimage__engine__s" ],
    [ "GVPLUGIN_LOADIMAGE_API", "gvplugin__loadimage_8h.html#a7ea731bc683ea2bc6c16a31816b66979", null ],
    [ "gvusershape_file_access", "gvplugin__loadimage_8h.html#ace9759d6e99ae1334fe3f22ed1ac3260", null ],
    [ "gvusershape_file_release", "gvplugin__loadimage_8h.html#adc549d8bf1744f7a1858e2713729b0ca", null ]
];