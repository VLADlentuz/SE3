var files_dup =
[
    [ "for lab", "dir_e6c23235d574a84b5ef1a8613e824ad0.html", "dir_e6c23235d574a84b5ef1a8613e824ad0" ],
    [ "PracticalSocket.cpp", "_practical_socket_8cpp.html", "_practical_socket_8cpp" ],
    [ "PracticalSocket.h", "_practical_socket_8h.html", "_practical_socket_8h" ]
];