var color_8h =
[
    [ "hsvrgbacolor_t", "structhsvrgbacolor__t.html", "structhsvrgbacolor__t" ],
    [ "color_s", "structcolor__s.html", "structcolor__s" ],
    [ "COLOR_MALLOC_FAIL", "color_8h.html#a33b51f43e7445305cc51be2f8cf37df5", null ],
    [ "COLOR_OK", "color_8h.html#a2bbbfc6b13243b5d5ea1159eed41942c", null ],
    [ "COLOR_UNKNOWN", "color_8h.html#aeae63bffec753f28eca373ef5ebd1493", null ],
    [ "gvcolor_t", "color_8h.html#ae1191eed3030f43658df2fef5fa202de", null ],
    [ "hsvrgbacolor_t", "color_8h.html#a512822a53763651db1a8dbc273cc96d3", null ],
    [ "color_type_t", "color_8h.html#a0254bf137f575a4c9b56103c6859fe20", [
      [ "HSVA_DOUBLE", "color_8h.html#a0254bf137f575a4c9b56103c6859fe20a4ec09b7c709fcb6ce271c8224e868182", null ],
      [ "RGBA_BYTE", "color_8h.html#a0254bf137f575a4c9b56103c6859fe20aa6fd28dfa5d78b69ad9a5a6663089563", null ],
      [ "RGBA_WORD", "color_8h.html#a0254bf137f575a4c9b56103c6859fe20aa2500a5f9637a454382c55acf03654f6", null ],
      [ "CMYK_BYTE", "color_8h.html#a0254bf137f575a4c9b56103c6859fe20abea14eaa37333c495d55bcdea07f44d7", null ],
      [ "RGBA_DOUBLE", "color_8h.html#a0254bf137f575a4c9b56103c6859fe20a87fbf87a09385a65d3080a64cf80b945", null ],
      [ "COLOR_STRING", "color_8h.html#a0254bf137f575a4c9b56103c6859fe20aef9051aa6077a779f60cc7bb2513913b", null ],
      [ "COLOR_INDEX", "color_8h.html#a0254bf137f575a4c9b56103c6859fe20ae60d922c402a91f1721af706f61ea466", null ]
    ] ]
];