var define_8h =
[
    [ "ABS", "define_8h.html#a996f7be338ccb40d1a2a5abc1ad61759", null ],
    [ "MAX", "define_8h.html#aacc3ee1a7f283f8ef65cea31f4436a95", null ],
    [ "MIN", "define_8h.html#a74e75242132eaabbc1c512488a135926", null ]
];