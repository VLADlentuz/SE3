var manual_8c =
[
    [ "Object", "struct_object.html", "struct_object" ],
    [ "Vehicle", "struct_vehicle.html", "struct_vehicle" ],
    [ "Car", "struct_car.html", "struct_car" ],
    [ "Truck", "struct_truck.html", "struct_truck" ],
    [ "Car", "manual_8c.html#a00b00bef7a37e8519a62cb3671105c4b", null ],
    [ "Object", "manual_8c.html#ab1287b6141419421dc5c14b9f7756b0a", null ],
    [ "Truck", "manual_8c.html#a5220977c04e056b0efcc59a2f05d89a2", null ],
    [ "Vehicle", "manual_8c.html#abe36c46f351fd80b9dd6401e7cce0b5d", null ],
    [ "main", "manual_8c.html#a840291bc02cba5474a4cb46a9b9566fe", null ]
];