var gvplugin_8h =
[
    [ "gvplugin_installed_t", "structgvplugin__installed__t.html", "structgvplugin__installed__t" ],
    [ "gvplugin_api_t", "structgvplugin__api__t.html", "structgvplugin__api__t" ],
    [ "gvplugin_library_t", "structgvplugin__library__t.html", "structgvplugin__library__t" ]
];