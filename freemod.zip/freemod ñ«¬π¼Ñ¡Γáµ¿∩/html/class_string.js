var class_string =
[
    [ "strcmp", "class_string.html#ae3c243f0bc797b9e4b15d2ef5e5aaa7c", null ],
    [ "stringDebug", "class_string.html#a5c07384b505d25ae6f61fc7abf0b0e61", null ]
];