var graphviz__version_8h =
[
    [ "GVPLUGIN_CONFIG_FILE", "graphviz__version_8h.html#ab67c029cfb2a990ac115edba943f777b", null ],
    [ "GVPLUGIN_VERSION", "graphviz__version_8h.html#a46c34223a421d030932aa1306475343f", null ],
    [ "PACKAGE_BUGREPORT", "graphviz__version_8h.html#a1d1d2d7f8d2f95b376954d649ab03233", null ],
    [ "PACKAGE_NAME", "graphviz__version_8h.html#a1c0439e4355794c09b64274849eb0279", null ],
    [ "PACKAGE_STRING", "graphviz__version_8h.html#ac73e6f903c16eca7710f92e36e1c6fbf", null ],
    [ "PACKAGE_TARNAME", "graphviz__version_8h.html#af415af6bfede0e8d5453708afe68651c", null ],
    [ "PACKAGE_URL", "graphviz__version_8h.html#a5c93853116d5a50307b6744f147840aa", null ],
    [ "PACKAGE_VERSION", "graphviz__version_8h.html#aa326a05d5e30f9e9a4bb0b4469d5d0c0", null ]
];