var class_communicating_socket =
[
    [ "CommunicatingSocket", "class_communicating_socket.html#a0017517b8d6e761fde0c40475af3b2ab", null ],
    [ "CommunicatingSocket", "class_communicating_socket.html#a27d758db782b3be7d28741e92cb613d1", null ],
    [ "CommunicatingSocket", "class_communicating_socket.html#a0017517b8d6e761fde0c40475af3b2ab", null ],
    [ "CommunicatingSocket", "class_communicating_socket.html#a27d758db782b3be7d28741e92cb613d1", null ],
    [ "connect", "class_communicating_socket.html#a9192374d9baab8e189860aa8d913683c", null ],
    [ "connect", "class_communicating_socket.html#a9192374d9baab8e189860aa8d913683c", null ],
    [ "getForeignAddress", "class_communicating_socket.html#a13f9eca30ef56836cf23c163c848c09e", null ],
    [ "getForeignAddress", "class_communicating_socket.html#a13f9eca30ef56836cf23c163c848c09e", null ],
    [ "getForeignPort", "class_communicating_socket.html#a184fbb4775184b87ebd886a5587eb1a3", null ],
    [ "getForeignPort", "class_communicating_socket.html#a184fbb4775184b87ebd886a5587eb1a3", null ],
    [ "recv", "class_communicating_socket.html#a7cf1fd470c0060171b68df9f68c7bd01", null ],
    [ "recv", "class_communicating_socket.html#a7cf1fd470c0060171b68df9f68c7bd01", null ],
    [ "send", "class_communicating_socket.html#aca4e86085c064641e86ae24ea29bbb94", null ],
    [ "send", "class_communicating_socket.html#aca4e86085c064641e86ae24ea29bbb94", null ]
];