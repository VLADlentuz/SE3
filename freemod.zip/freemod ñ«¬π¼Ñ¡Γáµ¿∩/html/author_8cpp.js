var author_8cpp =
[
    [ "SomeNiceClass", "class_some_nice_class.html", null ]
];