var group__modbus__utils =
[
    [ "xMBUtilGetBits", "group__modbus__utils.html#ga94b3b43e1d2353e621748c79e2fb4dd5", null ],
    [ "xMBUtilSetBits", "group__modbus__utils.html#gaffd1defb8bceb85f1b65d64fa1c895e1", null ]
];