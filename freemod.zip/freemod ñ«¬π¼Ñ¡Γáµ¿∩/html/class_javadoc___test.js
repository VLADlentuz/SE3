var class_javadoc___test =
[
    [ "TEnum", "class_javadoc___test.html#ae37fd1cbf1af522674cbd33873b786a6", [
      [ "TVal1", "class_javadoc___test.html#ae37fd1cbf1af522674cbd33873b786a6a90f0d8d4f07a79342261fb1c191af72b", null ],
      [ "TVal2", "class_javadoc___test.html#ae37fd1cbf1af522674cbd33873b786a6a5954e696a652f442d7255af4e0d35d61", null ],
      [ "TVal3", "class_javadoc___test.html#ae37fd1cbf1af522674cbd33873b786a6ab4a4dc16e1050c9604cf5c46a51e5a8e", null ]
    ] ],
    [ "Javadoc_Test", "class_javadoc___test.html#a17313327932ae97596b0a455ba8342cc", null ],
    [ "~Javadoc_Test", "class_javadoc___test.html#a60016cd15a4ed82bbc35be79a0a6a6b5", null ],
    [ "testMe", "class_javadoc___test.html#a0c472683ed25ff096e8a9edfb18d550c", null ],
    [ "testMeToo", "class_javadoc___test.html#ac2b39cabbe80957ae3e8bc2bd4e887f6", null ],
    [ "enumPtr", "class_javadoc___test.html#abcb36df9d8af3e69290c239ba483d6df", null ],
    [ "enumVar", "class_javadoc___test.html#afcc11e097968fb44080b82b75032e40b", null ],
    [ "handler", "class_javadoc___test.html#ace81a523a4eef44501a841a6d338832b", null ],
    [ "publicVar", "class_javadoc___test.html#a44a516fbc3a4865e2dcae34649c9df6a", null ]
];