var arith_8h =
[
    [ "_GNU_SOURCE", "arith_8h.html#a369266c24eacffb87046522897a570d5", null ],
    [ "AVG", "arith_8h.html#a5d66ce7f9d1958415dc8a5f9556e73b2", null ],
    [ "BETWEEN", "arith_8h.html#a043815e8b2e49280dc4fcd060fc56a38", null ],
    [ "CMP", "arith_8h.html#adf44891366ab95806ded6886a9f1c2ee", null ],
    [ "DEGREES", "arith_8h.html#aaee81a47de7098b758f6aadc3e2d9007", null ],
    [ "M_PI", "arith_8h.html#ae71449b1cc6e6250b91f539153a7a0d3", null ],
    [ "MAX", "arith_8h.html#afa99ec4acc4ecb2dc3c2d05da15d0e3f", null ],
    [ "MAXDOUBLE", "arith_8h.html#ace724a9256f4e65b352465e5feb24a21", null ],
    [ "MIN", "arith_8h.html#a3acffbd305ee72dcd4593c0d8af64a4f", null ],
    [ "RADIANS", "arith_8h.html#a4af1b2e9b11a7583daf59f2cb45a22e5", null ],
    [ "ROUND", "arith_8h.html#a91a8600e2a2859a47dbc2ba39960a352", null ],
    [ "SGN", "arith_8h.html#a0501e9b03fb5d244efedcc437ef66f68", null ],
    [ "sincos", "arith_8h.html#acc80bfed9382d1c32be56f4114e1fbeb", null ],
    [ "SQR", "arith_8h.html#ad41630f833e920c1ffa34722f45a8e77", null ],
    [ "SQRT2", "arith_8h.html#a514396dd60fa0621c83072091fb2a0cd", null ]
];